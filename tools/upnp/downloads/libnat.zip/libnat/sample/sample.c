/* Copyright (c) 2006 Adam Warrington
** $Id: sample.c,v 1.1.1.1 2006/03/13 15:54:53 awarring Exp $
**
** Permission is hereby granted, free of charge, to any person obtaining a copy
** of this software and associated documentation files (the "Software"), to deal
** in the Software without restriction, including without limitation the rights
** to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
** copies of the Software, and to permit persons to whom the Software is
** furnished to do so, subject to the following conditions:
**
** The above copyright notice and this permission notice shall be included in
** all copies or substantial portions of the Software.
**
** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
** IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
** FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
** AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
** LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
** OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
** SOFTWARE.
**
******************************************************************************
**
** This  file shows sample usage of LibNat's UPnP functions.
*/

#include <stdlib.h>
#include <stdio.h>
#include "../libnat/libnat.h"


int main(int argc, char* argv[])
{
  int ret;
  /* Declare the UPnP controller that will be used to pass information 
     about a possible router on the network to the other functions. This
     variable will be allocated from a discove request. */
  UpnpController * controller;
  /* we'll store the public ip in here. The LNat_Upnp_Get_Public_Ip
     function will allocate space for it, so we must later free it */
  char public_ip[32];

  /* if no router found, we'll print no router found and exit. Most
     usages of this library obviously won't want to exit on not finding
     a router on the network */
  if((ret = LNat_Upnp_Discover(&controller)) != 0) {
    LNat_Print_Error(ret);
    exit(EXIT_FAILURE);
  }
  printf("Discovery Successful.\n");

  /* Retrieve the public ip of the network. This is the IP Address of the
     router as seen by the public internet. */
  if((ret = LNat_Upnp_Get_Public_Ip(controller, public_ip, 32)) != 0) {
    LNat_Print_Error(ret);
    LNat_Upnp_Controller_Free(&controller);
    exit(EXIT_FAILURE);
  }
  printf("Public IP: %s.\n", public_ip);

  /* Forward all TCP data on port 4000 to this computer.
     NULL for the second parameter means remove this function will attempt
     to find the ip address of this computer, otherwise you could specify
     an ip address for the second parameter.*/
  if((ret = LNat_Upnp_Set_Port_Mapping(controller, NULL, 4000, "TCP")) != 0) {
    LNat_Print_Error(ret);
    LNat_Upnp_Controller_Free(&controller);
    free(public_ip);
    exit(EXIT_FAILURE);
  }
  printf("Port Mapping Successful On Port %d.\n", 4000);

  /* Remove the port forwarding of all TCP data on port 4000 to this computer.
     NULL for the second parameter means remove this function will attempt
     to find the ip address of this computer, otherwise you could specify
     an ip address for the second parameter. */
  if((ret = LNat_Upnp_Remove_Port_Mapping(controller, 4000, "TCP")) != 0) {
    LNat_Print_Error(ret);
    LNat_Upnp_Controller_Free(&controller);
    free(public_ip);
    exit(EXIT_FAILURE);
  }
  printf("Port Mapping Removal Successful On Port %d.\n", 4000);

  /* destroy the UpnpController object */
  LNat_Upnp_Controller_Free(&controller);

  printf("Everything Successful, Exiting...\n");
  return 0;
}
